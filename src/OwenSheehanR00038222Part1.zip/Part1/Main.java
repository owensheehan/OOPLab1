package Part1;

public class Main {

	public static void main(String[] args) {
		BottleSong mySong = new BottleSong(99);
		mySong.startSong();
		//new BottleSong(99).startSong();

	}

}
